# VagrantScripts
Vagrant adaption scripts
<br>
These are scripts to adapt a vanilla vagrant machine to enclose specific features
